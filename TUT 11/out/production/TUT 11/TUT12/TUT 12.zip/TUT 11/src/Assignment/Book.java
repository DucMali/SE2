package Assignment;

public class Book {
}
